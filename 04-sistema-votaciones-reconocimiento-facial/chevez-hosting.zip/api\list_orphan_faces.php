<?php
require_once 'config.php';
require_once 'aws_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $orphans = [];
    $allFaces = [];
    $nextToken = null;

    do {
        $params = [
            'CollectionId' => $collectionId,
            'MaxResults' => 100
        ];

        if ($nextToken) {
            $params['NextToken'] = $nextToken;
        }

        $result = $rekognitionClient->listFaces($params);

        if (!empty($result['Faces'])) {
            foreach ($result['Faces'] as $face) {
                $faceId = $face['FaceId'] ?? '';
                $externalImageId = $face['ExternalImageId'] ?? '';

                $allFaces[] = [
                    'FaceId' => $faceId,
                    'ExternalImageId' => $externalImageId
                ];

                $stmt = $conn->prepare("
                    SELECT id, nombre, correo, face_id
                    FROM usuarios
                    WHERE face_id = :face_id
                    LIMIT 1
                ");
                $stmt->execute([':face_id' => $faceId]);
                $userByFaceId = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$userByFaceId) {
                    $orphans[] = [
                        'face_id' => $faceId,
                        'external_image_id' => $externalImageId,
                        'reason' => 'No existe usuario con este face_id en la BD'
                    ];
                    continue;
                }

                if (!empty($externalImageId) && strval($userByFaceId['id']) !== strval($externalImageId)) {
                    $orphans[] = [
                        'face_id' => $faceId,
                        'external_image_id' => $externalImageId,
                        'db_user_id' => $userByFaceId['id'],
                        'db_user_name' => $userByFaceId['nombre'],
                        'reason' => 'ExternalImageId no coincide con el id real del usuario'
                    ];
                }
            }
        }

        $nextToken = $result['NextToken'] ?? null;
    } while ($nextToken);

    echo json_encode([
        'status' => 'success',
        'collection_id' => $collectionId,
        'total_faces_in_collection' => count($allFaces),
        'total_orphans' => count($orphans),
        'orphans' => $orphans
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error al listar rostros: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>