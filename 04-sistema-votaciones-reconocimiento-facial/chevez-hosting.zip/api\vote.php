<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$id_usuario = isset($data['id_usuario']) ? intval($data['id_usuario']) : 0;
$id_candidato = isset($data['id_candidato']) ? intval($data['id_candidato']) : 0;

$id_eleccion = isset($data['id_eleccion']) ? intval($data['id_eleccion']) : 0;

if (!$id_usuario || !$id_candidato || !$id_eleccion) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Datos de voto inválidos"]);
    exit;
}

try {
    // 1. Verificar si el usuario ya votó en ESTA elección
    $stmt = $conn->prepare("SELECT COUNT(*) FROM votos WHERE id_usuario = :uid AND id_eleccion = :eid");
    $stmt->execute([':uid' => $id_usuario, ':eid' => $id_eleccion]);
    $has_voted = $stmt->fetchColumn() > 0;

    if($has_voted) {
        http_response_code(403);
        echo json_encode(["status" => "error", "message" => "Ya has emitido tu voto en este tema de debate."]);
        exit;
    }

    // 2. Registrar el voto
    $stmt_voto = $conn->prepare("INSERT INTO votos (id_usuario, id_eleccion, id_candidato) VALUES (:uid, :eid, :cid)");
    $stmt_voto->execute([':uid' => $id_usuario, ':eid' => $id_eleccion, ':cid' => $id_candidato]);

    echo json_encode(["status" => "success", "message" => "Voto registrado exitosamente."]);
} catch (PDOException $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    // Log el error real en el servidor (no se expone al cliente)
    error_log("[vote.php] PDOException: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "No se pudo registrar el voto. Intenta de nuevo o contacta al administrador."]);
}
?>
