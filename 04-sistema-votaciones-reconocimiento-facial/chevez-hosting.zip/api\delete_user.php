<?php
require_once 'config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$email = isset($data['email']) ? trim($data['email']) : '';

if (empty($email)) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Email no proporcionado"]);
    exit();
}

try {
    if ($email === 'ALL') {
        $conn->exec("TRUNCATE TABLE usuarios");
        echo json_encode(["status" => "success", "message" => "Base de datos borrada"]);
    } else {
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE correo = :correo");
        $stmt->execute([':correo' => $email]);
        echo json_encode(["status" => "success", "message" => "Usuario eliminado"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "SQL Error: " . $e->getMessage()]);
}
?>
