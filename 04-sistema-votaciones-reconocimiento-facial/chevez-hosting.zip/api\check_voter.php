<?php
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$id) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "ID inválido"]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM votos WHERE id_usuario = :uid");
    $stmt->execute([':uid' => $id]);
    $total = (int)$stmt->fetchColumn();

    echo json_encode([
        "status" => "success",
        "ya_voto" => $total > 0 ? 1 : 0,
        "total_votos" => $total
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error de BD"]);
}
?>