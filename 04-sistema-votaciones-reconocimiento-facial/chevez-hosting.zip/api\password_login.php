<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['clave'])) {
    echo json_encode(["status" => "error", "message" => "Faltan datos obligatorios"]);
    exit();
}

$email = trim($data['email']);
$clave = trim($data['clave']);

try {
    $stmt = $conn->prepare("SELECT id, nombre, correo, clave, estado FROM usuarios WHERE correo = :correo");
    $stmt->execute([':correo' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(["status" => "error", "message" => "Correo no encontrado en el padrón."]);
        exit();
    }

    if (empty($user['clave'])) {
        echo json_encode(["status" => "error", "message" => "No tienes ninguna clave de respaldo vinculada a este correo. Requiere reconocimiento facial o contactar administración."]);
        exit();
    }

    if (!password_verify($clave, $user['clave'])) {
        echo json_encode(["status" => "error", "message" => "Contraseña incorrecta."]);
        exit();
    }

    // Buscar en qué elecciones ha votado
    $stmtVotos = $conn->prepare("SELECT id_eleccion FROM votos WHERE id_usuario = :uid");
    $stmtVotos->execute([':uid' => $user['id']]);
    $voted_elections = $stmtVotos->fetchAll(PDO::FETCH_COLUMN);

    // Success
    echo json_encode([
        "status" => "success", 
        "user" => [
            "id" => $user['id'],
            "nombre" => $user['nombre'],
            "email" => $user['correo'],
            "voted_elections" => $voted_elections
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Ocurrió un error inesperado al procesar la solicitud."]);
}
?>
