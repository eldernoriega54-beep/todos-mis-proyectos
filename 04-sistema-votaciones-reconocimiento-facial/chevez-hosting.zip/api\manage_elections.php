<?php
require_once 'config.php';
header('Content-Type: application/json');

$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    if ($action === 'get') {
        $stmt = $conn->query("SELECT * FROM elecciones ORDER BY id DESC");
        $elections = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(["status" => "success", "data" => $elections]);
    } 
    elseif ($action === 'add') {
        $data = json_decode(file_get_contents("php://input"), true);
        $titulo = trim($data['titulo']);
        
        if(!$titulo) {
            echo json_encode(["status" => "error", "message" => "Título es obligatorio"]);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO elecciones (titulo, estado) VALUES (:tit, 'inactiva')");
        $stmt->execute([':tit' => $titulo]);
        echo json_encode(["status" => "success"]);
    }
    elseif ($action === 'toggle') {
        $data = json_decode(file_get_contents("php://input"), true);
        $id = intval($data['id']);
        $nuevo_estado = $data['estado']; // 'activa' o 'inactiva'

        $stmt = $conn->prepare("UPDATE elecciones SET estado = :est WHERE id = :id");
        $stmt->execute([':est' => $nuevo_estado, ':id' => $id]);
        echo json_encode(["status" => "success"]);
    }
    elseif ($action === 'delete') {
        $data = json_decode(file_get_contents("php://input"), true);
        $id = intval($data['id']);
        
        // Primero, borrar fotos de candidatos asociados a esta elección
        $stmtFoto = $conn->prepare("SELECT foto_url FROM candidatos WHERE id_eleccion = :id");
        $stmtFoto->execute([':id' => $id]);
        while($cand = $stmtFoto->fetch(PDO::FETCH_ASSOC)){
            if (!empty($cand['foto_url'])) {
                $fileToDelete = '../' . $cand['foto_url'];
                if (file_exists($fileToDelete)) {
                    unlink($fileToDelete);
                }
            }
        }

        // Borrar todos los votos y candidatos está manejado por ON DELETE CASCADE en la BD,
        // pero preferimos forzar borrar desde PDO o confiar en la FK. 
        // Ya que usamos ON DELETE CASCADE en update_db.php, la eleccion se borra limpia.
        $stmt = $conn->prepare("DELETE FROM elecciones WHERE id = :id");
        $stmt->execute([':id' => $id]);
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
    }
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "SQL Error: " . $e->getMessage()]);
}
?>
