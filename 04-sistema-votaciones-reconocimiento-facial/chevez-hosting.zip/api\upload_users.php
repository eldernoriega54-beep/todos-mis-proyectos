<?php
require_once 'config.php';
require_once 'vendor/autoload.php';
use Shuchkin\SimpleXLSX;

header('Content-Type: application/json');

if (!isset($_FILES['csvFile']) || $_FILES['csvFile']['error'] != UPLOAD_ERR_OK) {
    echo json_encode(['status' => 'error', 'message' => 'Error en la subida del archivo.']);
    exit;
}

$tmpName = $_FILES['csvFile']['tmp_name'];
$fileName = strtolower($_FILES['csvFile']['name']);
$ext = pathinfo($fileName, PATHINFO_EXTENSION);

$inserted = 0;
$skipped = 0;

// Dominio institucional por defecto
define('EMAIL_DOMAIN', '@iehchevezhn.com');

/**
 * Si el correo no contiene '@', se le agrega el dominio institucional.
 */
function normalizeEmail(string $email): string {
    $email = trim($email);
    if ($email === '') return '';
    if (strpos($email, '@') === false) {
        $email = $email . EMAIL_DOMAIN;
    }
    return strtolower($email);
}

$stmt = $conn->prepare("INSERT IGNORE INTO usuarios (nombre, correo) VALUES (:nombre, :correo)");

if ($ext === 'xlsx') {
    if ($xlsx = SimpleXLSX::parse($tmpName)) {
        $rows = $xlsx->rows();
        foreach ($rows as $index => $data) {
            if ($index === 0) continue; // Skip header
            if (count($data) < 3) continue;

            $firstName = trim($data[0]);
            $lastName = trim($data[1]);
            $email = normalizeEmail($data[2]);
            
            if (empty($firstName) || empty($email)) continue; // Required fields
            $nombreCompleto = $firstName . ' ' . $lastName;

            try {
                $stmt->execute([':nombre' => $nombreCompleto, ':correo' => $email]);
                if ($stmt->rowCount() > 0) $inserted++;
                else $skipped++;
            } catch(PDOException $e) { $skipped++; }
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error parseando el archivo XLSX: ' . SimpleXLSX::parseError()]);
        exit;
    }
} elseif ($ext === 'csv') {
    $handle = fopen($tmpName, "r");
    if ($handle === FALSE) {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo leer el archivo CSV.']);
        exit;
    }
    
    $header = fgetcsv($handle, 1000, ",");
    
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if (count($data) < 3) continue;

        $firstName = trim($data[0]);
        $lastName = trim($data[1]);
        $email = normalizeEmail($data[2]);
        
        if (empty($firstName) || empty($email)) continue;

        $nombreCompleto = $firstName . ' ' . $lastName;

        try {
            $stmt->execute([':nombre' => $nombreCompleto, ':correo' => $email]);
            if ($stmt->rowCount() > 0) $inserted++;
            else $skipped++;
        } catch(PDOException $e) { $skipped++; }
    }
    fclose($handle);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Formato de archivo no soportado. Sube un .csv o .xlsx']);
    exit;
}

echo json_encode([
    'status' => 'success', 
    'message' => "Carga masiva completada. $inserted estudiantes procesados correctamente. $skipped omitidos (ya existían)."
]);
?>
