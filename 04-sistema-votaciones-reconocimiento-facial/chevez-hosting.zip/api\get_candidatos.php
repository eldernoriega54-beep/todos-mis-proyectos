<?php
require_once 'config.php';
header('Content-Type: application/json');

try {
    $stmt = $conn->query("SELECT id, nombre, foto_url, propuesta FROM candidatos");
    $cands = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(["status" => "success", "data" => $cands]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "SQL Error"]);
}
?>
