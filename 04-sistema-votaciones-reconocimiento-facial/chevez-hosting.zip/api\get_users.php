<?php
require_once 'config.php';

header('Content-Type: application/json');

try {
    $stmt = $conn->query("
        SELECT 
            id, nombre, correo, clave, face_id, estado,
            (SELECT COUNT(*) FROM votos WHERE id_usuario = usuarios.id) as total_votos
        FROM usuarios 
        ORDER BY id DESC
    ");
    $users = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $users[] = $row;
    }
    echo json_encode(["status" => "success", "data" => $users]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "SQL Error: " . $e->getMessage()]);
}
?>
