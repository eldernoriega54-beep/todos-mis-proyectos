<?php
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents("php://input"), true);
$method = $data['method'] ?? '';

// ===============================
// LOGIN POR CONTRASEÑA
// ===============================
if ($method === 'password') {

    $user = trim($data['usuario'] ?? '');
    $pass = $data['contrasena'] ?? '';

    if ($user === '' || $pass === '') {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Usuario y contraseña son obligatorios."
        ]);
        exit();
    }

    try {
        $stmt = $conn->prepare("SELECT usuario, contrasena FROM administradores WHERE usuario = :user LIMIT 1");
        $stmt->execute([':user' => $user]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            http_response_code(401);
            echo json_encode([
                "status" => "error",
                "message" => "Credenciales incorrectas"
            ]);
            exit();
        }

        $storedPassword = $row['contrasena'];

        // 🔥 SOLUCIÓN DEFINITIVA
        $passwordOk = false;

        // 1. texto plano
        if ($pass === $storedPassword) {
            $passwordOk = true;
        }

        // 2. hash
        if (!$passwordOk && password_verify($pass, $storedPassword)) {
            $passwordOk = true;
        }

        if ($passwordOk) {
            echo json_encode([
                "status" => "success",
                "usuario" => $row['usuario'],
                "token" => bin2hex(random_bytes(16))
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                "status" => "error",
                "message" => "Credenciales incorrectas"
            ]);
        }

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "Error interno: " . $e->getMessage()
        ]);
    }
}

// ===============================
// OBTENER ROSTROS
// ===============================
elseif ($method === 'get_faces') {

    try {
        $stmt = $conn->query("SELECT usuario, descriptor_rostro FROM administradores WHERE descriptor_rostro IS NOT NULL");

        $admins = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $admins[] = [
                "usuario" => $row['usuario'],
                "descriptor" => json_decode($row['descriptor_rostro'], true)
            ];
        }

        echo json_encode([
            "status" => "success",
            "data" => $admins
        ]);

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => $e->getMessage()
        ]);
    }
}

// ===============================
// LOGIN FACIAL
// ===============================
elseif ($method === 'face_login') {

    $user = trim($data['usuario'] ?? '');

    if ($user === '') {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Usuario requerido"
        ]);
        exit();
    }

    try {
        $stmt = $conn->prepare("SELECT id FROM administradores WHERE usuario = :user LIMIT 1");
        $stmt->execute([':user' => $user]);

        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            echo json_encode([
                "status" => "success",
                "usuario" => $user,
                "token" => bin2hex(random_bytes(16))
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                "status" => "error",
                "message" => "Administrador no encontrado"
            ]);
        }

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => $e->getMessage()
        ]);
    }
}

// ===============================
// CREAR ADMIN
// ===============================
elseif ($method === 'create') {

    $user = trim($data['usuario'] ?? '');
    $pass = $data['contrasena'] ?? '';

    if ($user === '' || $pass === '') {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Datos incompletos"
        ]);
        exit();
    }

    try {
        $stmt = $conn->prepare("INSERT INTO administradores (usuario, contrasena) VALUES (:user, :pass)");
        $stmt->execute([
            ':user' => $user,
            ':pass' => $pass // 🔥 texto plano para no complicarte
        ]);

        echo json_encode(["status" => "success"]);

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => "El usuario ya existe"
        ]);
    }
}

// ===============================
// ACTUALIZAR ROSTRO
// ===============================
elseif ($method === 'update_face') {

    $user = trim($data['usuario'] ?? '');
    $descriptor = isset($data['descriptor']) ? json_encode($data['descriptor']) : null;

    if ($user === '' || $descriptor === null) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Datos incompletos"
        ]);
        exit();
    }

    try {
        $stmt = $conn->prepare("UPDATE administradores SET descriptor_rostro = :desc WHERE usuario = :user");
        $stmt->execute([
            ':desc' => $descriptor,
            ':user' => $user
        ]);

        echo json_encode(["status" => "success"]);

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            "status" => "error",
            "message" => $e->getMessage()
        ]);
    }
}

// ===============================
else {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Método inválido"
    ]);
}
?>