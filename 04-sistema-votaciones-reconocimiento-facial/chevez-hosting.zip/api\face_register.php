﻿<?php
require_once 'config.php';
require_once 'aws_config.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || !isset($data['imagen_base64'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Faltan datos obligatorios"]);
    exit();
}

$nombre = trim($data['nombre'] ?? 'Visitante');
$email = trim($data['email']);
$imagen_base64 = $data['imagen_base64'];

if (strpos($imagen_base64, ',') !== false) {
    @list($type, $imagen_base64) = explode(',', $imagen_base64);
}
$imagenBytes = base64_decode($imagen_base64);

try {
    // 1. Validar rostro y buscar en AWS
    try {
        $searchResult = $rekognitionClient->searchFacesByImage([
            'CollectionId' => $collectionId,
            'Image' => ['Bytes' => $imagenBytes],
            'MaxFaces' => 1,
            'FaceMatchThreshold' => 80
        ]);

        if (!empty($searchResult['FaceMatches'])) {
            // ROSTRO ENCONTRADO -> LOGIN
            $userId = $searchResult['FaceMatches'][0]['Face']['ExternalImageId'];
            
            $stmt = $conn->prepare("SELECT id, nombre, correo FROM usuarios WHERE id = :id");
            $stmt->execute([':id' => $userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Obtener elecciones votadas
                $stmtVotes = $conn->prepare("SELECT DISTINCT id_eleccion FROM votos WHERE id_usuario = :uid");
                $stmtVotes->execute([':uid' => $user['id']]);
                $voted = $stmtVotes->fetchAll(PDO::FETCH_COLUMN);
                $user['voted_elections'] = $voted;

                echo json_encode([
                    "status" => "success", 
                    "message" => "¡Rostro reconocido! Bienvenido de nuevo, " . $user['nombre'],
                    "user" => $user
                ]);
                exit();
            }
        }
    } catch (Exception $e) {
        // Ignorar si no se encuentra o la coleccion está vacia. Atraparemos errores graves abajo.
        if (strpos($e->getMessage(), 'There are no faces') !== false || strpos($e->getMessage(), 'No se detectó') !== false) {
            echo json_encode(["status" => "error", "message" => "No se detectó un rostro claro."]);
            exit();
        }
    }

    // SI NO SE ENCONTRÓ EL ROSTRO -> REGISTRO NUEVO
    
    // Primero, crear el usuario en la DB para tener un ID
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo) VALUES (:nombre, :correo)");
    try {
        $stmt->execute([':nombre' => $nombre, ':correo' => $email]);
        $userId = $conn->lastInsertId();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Correo duplicado pero sin rostro
            $stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = :correo");
            $stmt->execute([':correo' => $email]);
            $userId = $stmt->fetchColumn();
        } else {
            throw $e;
        }
    }

    // Indexar en AWS
    $indexResult = $rekognitionClient->indexFaces([
        'CollectionId' => $collectionId,
        'ExternalImageId' => (string)$userId,
        'Image' => ['Bytes' => $imagenBytes],
        'DetectionAttributes' => []
    ]);

    if (empty($indexResult['FaceRecords'])) {
        throw new Exception("No se pudo registrar el rostro en AWS.");
    }
    $faceId = $indexResult['FaceRecords'][0]['Face']['FaceId'];

    // Actualizar DB con FaceID
    $updateSql = "UPDATE usuarios SET face_id = :face_id, collection_id = :collection_id WHERE id = :id";
    $stmtUpdate = $conn->prepare($updateSql);
    $stmtUpdate->execute([
        ':face_id' => $faceId,
        ':collection_id' => $collectionId,
        ':id' => $userId
    ]);

    // Retornar usuario
    echo json_encode([
        "status" => "success", 
        "message" => "Registro exitoso.",
        "user" => [
            "id" => $userId,
            "nombre" => $nombre,
            "correo" => $email,
            "voted_elections" => []
        ]
    ]);

} catch (Exception $ex) {
    error_log("[kiosk] Error: " . $ex->getMessage());
    echo json_encode([
        "status" => "error",
        "message" => "Error interno del sistema."
    ]);
}
?>
