<?php
require_once 'config.php';
header('Content-Type: application/json');

try {
    $id_eleccion = isset($_GET['id_eleccion']) ? intval($_GET['id_eleccion']) : 0;
    
    if ($id_eleccion > 0) {
        $sql = "
            SELECT 
                c.id, 
                c.nombre, 
                c.foto_url,
                (SELECT COUNT(*) FROM votos v WHERE v.id_candidato = c.id) as total_votos
            FROM candidatos c
            WHERE c.id_eleccion = :id_eleccion
            ORDER BY total_votos DESC
        ";
        $stmt = $conn->prepare($sql);
        $stmt->execute([':id_eleccion' => $id_eleccion]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get total votes cast
        $stmt_total = $conn->prepare("SELECT COUNT(*) as total FROM votos WHERE id_eleccion = :id_eleccion");
        $stmt_total->execute([':id_eleccion' => $id_eleccion]);
        $total = $stmt_total->fetch(PDO::FETCH_ASSOC)['total'];
    } else {
        // Return empty if no election selected
        $results = [];
        $total = 0;
    }

    echo json_encode(["status" => "success", "data" => $results, "total_general" => $total]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "SQL Error"]);
}
?>
