<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$nombre = trim($data['nombre'] ?? '');
$correo = trim($data['correo'] ?? '');

if (empty($nombre) || empty($correo)) {
    echo json_encode(["status" => "error", "message" => "Nombre y correo son obligatorios."]);
    exit();
}

// El correo se guarda tal cual se recibe
$correo = strtolower($correo);

try {
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, correo) VALUES (:nombre, :correo)");
    $stmt->execute([':nombre' => $nombre, ':correo' => $correo]);
    echo json_encode(["status" => "success", "message" => "Usuario agregado correctamente."]);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) { // Constraint violation (Duplicate entry)
        echo json_encode(["status" => "error", "message" => "El correo '$correo' ya está registrado."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error en la base de datos."]);
    }
}
?>
