<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$nombre = isset($data['nombre']) ? trim($data['nombre']) : '';
$email  = isset($data['email'])  ? trim($data['email'])  : '';
$clave  = isset($data['clave'])  ? trim($data['clave'])  : '';

if (!$nombre || !$email || !$clave) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Nombre, correo y clave son obligatorios para el registro sin cámara."]);
    exit;
}

if (strlen($clave) < 3) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "La clave debe tener al menos 3 caracteres."]);
    exit;
}

try {
    // Verificar que el correo exista en el padrón
    $stmt = $conn->prepare("SELECT id, face_id, clave FROM usuarios WHERE correo = :correo");
    $stmt->execute([':correo' => $email]);
    $userRow = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$userRow) {
        echo json_encode(["status" => "error", "message" => "Tu correo no está registrado en el padrón institucional. Verifícalo o contacta administración."]);
        exit;
    }

    if (!empty($userRow['face_id'])) {
        echo json_encode(["status" => "error", "message" => "Este correo ya tiene un rostro registrado biométricamente. Usa el reconocimiento facial para votar."]);
        exit;
    }

    if (!empty($userRow['clave'])) {
        echo json_encode(["status" => "error", "message" => "Este correo ya tiene una clave de respaldo registrada."]);
        exit;
    }

    // Guardar solo la clave hasheada (sin face_id)
    $hashedClave = password_hash($clave, PASSWORD_DEFAULT);
    $stmtUpd = $conn->prepare("UPDATE usuarios SET clave = :clave WHERE id = :id");
    $stmtUpd->execute([':clave' => $hashedClave, ':id' => $userRow['id']]);

    echo json_encode([
        "status"  => "success",
        "message" => "Clave de respaldo guardada correctamente. Podrás votar usando tu correo y esta clave."
    ]);

} catch (PDOException $e) {
    error_log("[register_no_face.php] " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error interno al guardar los datos."]);
}
?>
