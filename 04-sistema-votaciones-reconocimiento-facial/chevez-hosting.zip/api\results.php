<?php
header('Content-Type: application/json; charset=utf-8');

$host = "localhost";
$user = "root";
$pass = "";
$db = "facial_votaciones";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$conn->set_charset("utf8mb4");

$election_id = isset($_GET['election_id']) ? intval($_GET['election_id']) : 0;

if ($election_id <= 0) {
    echo json_encode([]);
    exit;
}

$sql = "
    SELECT 
        c.id,
        c.nombre,
        c.foto_url,
        COUNT(v.id) AS votos
    FROM candidatos c
    LEFT JOIN votos v 
        ON v.id_candidato = c.id
        AND v.id_eleccion = ?
    WHERE c.id_eleccion = ?
    GROUP BY c.id, c.nombre, c.foto_url
    ORDER BY votos DESC, c.nombre ASC
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "Error al preparar la consulta: " . $conn->error
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt->bind_param("ii", $election_id, $election_id);

if (!$stmt->execute()) {
    echo json_encode([
        "status" => "error",
        "message" => "Error al ejecutar la consulta: " . $stmt->error
    ], JSON_UNESCAPED_UNICODE);
    $stmt->close();
    $conn->close();
    exit;
}

$result = $stmt->get_result();
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        "id"     => (int)$row["id"],
        "nombre" => $row["nombre"],
        "foto"   => !empty($row["foto_url"]) ? $row["foto_url"] : "",
        "votos"  => (int)$row["votos"]
    ];
}

echo json_encode($data, JSON_UNESCAPED_UNICODE);

$stmt->close();
$conn->close();
?>