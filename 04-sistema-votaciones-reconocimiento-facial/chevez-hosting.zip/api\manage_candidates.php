<?php
require_once 'config.php';
header('Content-Type: application/json');

$action = isset($_GET['action']) ? $_GET['action'] : '';

// Ensure uploads directory exists
$uploadDir = '../uploads/candidatos/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($action === 'get') {
    $id_eleccion = isset($_GET['id_eleccion']) ? intval($_GET['id_eleccion']) : null;
    if ($id_eleccion) {
        $stmt = $conn->prepare("SELECT * FROM candidatos WHERE id_eleccion = :id_eleccion");
        $stmt->execute([':id_eleccion' => $id_eleccion]);
        $cands = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $conn->query("SELECT * FROM candidatos");
        $cands = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    echo json_encode(["status" => "success", "data" => $cands]);
}
elseif ($action === 'add') {
    $data = json_decode(file_get_contents("php://input"), true);
    $id_eleccion = isset($data['id_eleccion']) ? intval($data['id_eleccion']) : 0;
    $nombre = trim($data['nombre']);
    $propuesta = trim($data['propuesta']);
    $foto_base64 = $data['foto']; // base64 string

    if(!$id_eleccion || !$nombre || !$foto_base64) {
        echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
        exit;
    }

    // Clean base64 string and write to file
    if (strpos($foto_base64, ',') !== false) {
        @list($type, $foto_base64) = explode(',', $foto_base64);
    }
    $imagenBytes = base64_decode($foto_base64);

    // Generate unique filename
    $filename = 'cand_' . time() . '_' . uniqid() . '.jpg';
    $filepath = $uploadDir . $filename;
    
    // Save image to server
    if (file_put_contents($filepath, $imagenBytes) === false) {
        echo json_encode(["status" => "error", "message" => "Error guardando la foto en el directorio"]);
        exit;
    }

    // Store URL path in database (relative to frontend)
    $foto_url = 'uploads/candidatos/' . $filename;

    $stmt = $conn->prepare("INSERT INTO candidatos (id_eleccion, nombre, foto_url, propuesta) VALUES (:id_eleccion, :nom, :foto_url, :prop)");
    $stmt->execute([':id_eleccion' => $id_eleccion, ':nom' => $nombre, ':foto_url' => $foto_url, ':prop' => $propuesta]);
    echo json_encode(["status" => "success"]);
}
elseif ($action === 'delete') {
    $data = json_decode(file_get_contents("php://input"), true);
    $id = intval($data['id']);
    
    try {
        $conn->beginTransaction();

        // Eliminar la foto del servidor primero
        $stmt = $conn->prepare("SELECT foto_url FROM candidatos WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $cand = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($cand && !empty($cand['foto_url'])) {
            $fileToDelete = '../' . $cand['foto_url'];
            if (file_exists($fileToDelete)) {
                unlink($fileToDelete);
            }
        }

        // Borrar el candidato (ON DELETE CASCADE borrará los votos automáticamente)
        $stmt = $conn->prepare("DELETE FROM candidatos WHERE id = :id");
        $stmt->execute([':id' => $id]);

        $conn->commit();
        echo json_encode(["status" => "success", "message" => "Candidato eliminado exitosamente."]);
    } catch (PDOException $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        error_log("[manage_candidates.php] delete error: " . $e->getMessage());
        echo json_encode(["status" => "error", "message" => "Error al eliminar: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
}
?>
