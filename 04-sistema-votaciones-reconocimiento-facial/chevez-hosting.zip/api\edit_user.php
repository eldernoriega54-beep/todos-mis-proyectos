<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$id = intval($data['id'] ?? 0);
$nombre = trim($data['nombre'] ?? '');
$correo = trim($data['correo'] ?? '');

if ($id <= 0 || empty($nombre) || empty($correo)) {
    echo json_encode(["status" => "error", "message" => "ID, Nombre y correo son obligatorios."]);
    exit();
}

// El correo se guarda tal cual se recibe
$correo = strtolower($correo);

try {
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = :nombre, correo = :correo WHERE id = :id");
    $stmt->execute([':nombre' => $nombre, ':correo' => $correo, ':id' => $id]);
    echo json_encode(["status" => "success", "message" => "Usuario actualizado correctamente."]);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) { 
        echo json_encode(["status" => "error", "message" => "El correo '$correo' ya está siendo usado por otro usuario."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error en la base de datos."]);
    }
}
?>
