<?php
require_once 'aws_config.php';

try {
    echo "Verificando/Creando colección AWS...\n";
    $result = $rekognitionClient->createCollection([
        'CollectionId' => $collectionId
    ]);
    echo "¡La colección '$collectionId' se creó exitosamente!\n";
} catch (Exception $e) {
    if (strpos($e->getMessage(), 'ResourceAlreadyExistsException') !== false) {
        echo "La colección '$collectionId' ya existe, ¡todo listo para usar!\n";
    } else {
        echo "Error: " . $e->getMessage() . "\n";
    }
}
?>
