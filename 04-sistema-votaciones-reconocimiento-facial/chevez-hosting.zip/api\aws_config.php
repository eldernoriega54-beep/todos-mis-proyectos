<?php
// Cargar AWS SDK desde Composer autoloader
require_once __DIR__ . '/vendor/autoload.php';

use Aws\Rekognition\RekognitionClient;

// Configuración de credenciales y región
// IMPORTANTE: Debes colocar tus credenciales reales aquí si no usas variables de entorno AWS
$awsConfig = [
    'region'  => 'us-east-1',
    'version' => 'latest',
    'credentials' => [
        'key'    => 'AKIAXJYQEG3ZNMYUDSTM',
        'secret' => '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',
    ]
];

try {
    $rekognitionClient = new RekognitionClient($awsConfig);
} catch (Exception $e) {
    die("Error al inicializar AWS Rekognition: " . $e->getMessage());
}

$collectionId = 'alumnos-iehc'; // Nombre de la colección de rostros en AWS Rekognition
?>
