<?php
require_once 'config.php';

try {
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("SET FOREIGN_KEY_CHECKS=0;");

    // 1. Crear tabla elecciones
    $conn->exec("CREATE TABLE IF NOT EXISTS elecciones (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        titulo VARCHAR(255) NOT NULL,
        estado ENUM('activa', 'inactiva') DEFAULT 'inactiva',
        fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB;");
    echo "Tabla elecciones creada.<br>";

    // 2. Modificar candidatos
    $conn->exec("DROP TABLE IF EXISTS candidatos");
    $conn->exec("CREATE TABLE candidatos (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        id_eleccion INT(11) NOT NULL,
        nombre VARCHAR(255) NOT NULL,
        propuesta TEXT,
        foto_url VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_eleccion) REFERENCES elecciones(id) ON DELETE CASCADE
    ) ENGINE=InnoDB;");
    echo "Tabla candidatos recreada con id_eleccion.<br>";

    // 3. Modificar votos
    $conn->exec("DROP TABLE IF EXISTS votos");
    $conn->exec("CREATE TABLE votos (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        id_usuario INT(11) NOT NULL,
        id_eleccion INT(11) NOT NULL,
        id_candidato INT(11) NOT NULL,
        fecha_voto TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
        FOREIGN KEY (id_eleccion) REFERENCES elecciones(id) ON DELETE CASCADE,
        FOREIGN KEY (id_candidato) REFERENCES candidatos(id) ON DELETE CASCADE,
        UNIQUE KEY(id_usuario, id_eleccion) -- Garantiza un solo voto por usuario por elección
    ) ENGINE=InnoDB;");
    echo "Tabla votos recreada con id_eleccion y validacion unica.<br>";

    // 4. Quitar ya_voto de usuarios
    // Ignore error if column doesn't exist
    try {
        $conn->exec("ALTER TABLE usuarios DROP COLUMN ya_voto;");
        echo "Columna ya_voto eliminada de usuarios.<br>";
    } catch(PDOException $e) {
        echo "Aviso (ya_voto): " . $e->getMessage() . "<br>";
    }

    $conn->exec("SET FOREIGN_KEY_CHECKS=1;");
    echo "<b>Migración de base de datos exitosa.</b>";

} catch (PDOException $e) {
    echo "Error fatal: " . $e->getMessage();
}
?>
