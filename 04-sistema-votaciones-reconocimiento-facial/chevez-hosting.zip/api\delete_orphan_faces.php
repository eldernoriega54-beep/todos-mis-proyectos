<?php
require_once 'config.php';
require_once 'aws_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $orphanFaceIds = [];
    $nextToken = null;

    do {
        $params = [
            'CollectionId' => $collectionId,
            'MaxResults' => 100
        ];

        if ($nextToken) {
            $params['NextToken'] = $nextToken;
        }

        $result = $rekognitionClient->listFaces($params);

        if (!empty($result['Faces'])) {
            foreach ($result['Faces'] as $face) {
                $faceId = $face['FaceId'] ?? '';
                $externalImageId = $face['ExternalImageId'] ?? '';

                $stmt = $conn->prepare("
                    SELECT id, nombre, correo, face_id
                    FROM usuarios
                    WHERE face_id = :face_id
                    LIMIT 1
                ");
                $stmt->execute([':face_id' => $faceId]);
                $userByFaceId = $stmt->fetch(PDO::FETCH_ASSOC);

                $isOrphan = false;

                if (!$userByFaceId) {
                    $isOrphan = true;
                } elseif (!empty($externalImageId) && strval($userByFaceId['id']) !== strval($externalImageId)) {
                    $isOrphan = true;
                }

                if ($isOrphan && !empty($faceId)) {
                    $orphanFaceIds[] = $faceId;
                }
            }
        }

        $nextToken = $result['NextToken'] ?? null;
    } while ($nextToken);

    $deleted = [];

    if (!empty($orphanFaceIds)) {
        $chunks = array_chunk($orphanFaceIds, 100);

        foreach ($chunks as $chunk) {
            $deleteResult = $rekognitionClient->deleteFaces([
                'CollectionId' => $collectionId,
                'FaceIds' => $chunk
            ]);

            if (!empty($deleteResult['DeletedFaces'])) {
                $deleted = array_merge($deleted, $deleteResult['DeletedFaces']);
            }
        }
    }

    echo json_encode([
        'status' => 'success',
        'collection_id' => $collectionId,
        'found_orphans' => count($orphanFaceIds),
        'deleted_faces' => $deleted,
        'deleted_count' => count($deleted)
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error al eliminar rostros huérfanos: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>