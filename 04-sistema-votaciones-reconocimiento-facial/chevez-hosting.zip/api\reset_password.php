<?php
require_once 'config.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$id_usuario  = isset($data['id_usuario'])  ? intval($data['id_usuario'])       : 0;
$nueva_clave = isset($data['nueva_clave']) ? trim($data['nueva_clave'])         : '';

if (!$id_usuario || strlen($nueva_clave) < 3) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Datos inválidos. La clave debe tener al menos 3 caracteres."]);
    exit;
}

try {
    // Verificar que el usuario existe
    $stmt = $conn->prepare("SELECT id, nombre FROM usuarios WHERE id = :uid");
    $stmt->execute([':uid' => $id_usuario]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Usuario no encontrado."]);
        exit;
    }

    // Hashear la clave (compatible con password_verify en password_login.php)
    $hash = password_hash($nueva_clave, PASSWORD_DEFAULT);
    $stmt_upd = $conn->prepare("UPDATE usuarios SET clave = :clave WHERE id = :uid");
    $stmt_upd->execute([':clave' => $hash, ':uid' => $id_usuario]);

    echo json_encode([
        "status"  => "success",
        "message" => "Clave actualizada correctamente para " . $user['nombre']
    ]);

} catch (PDOException $e) {
    error_log("[reset_password.php] " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error al actualizar la clave."]);
}
?>
