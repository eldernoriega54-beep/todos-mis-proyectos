<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents("php://input"), true);
$id_usuario = isset($data['id_usuario']) ? intval($data['id_usuario']) : 0;

if ($id_usuario <= 0) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "ID de usuario inválido."
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    $conn->beginTransaction();

    // Eliminar todos los votos del usuario
    $stmt = $conn->prepare("DELETE FROM votos WHERE id_usuario = :uid");
    $stmt->execute([':uid' => $id_usuario]);

    $totalEliminados = $stmt->rowCount();

    $conn->commit();

    echo json_encode([
        "status" => "success",
        "message" => $totalEliminados > 0
            ? "Los votos del estudiante fueron eliminados correctamente."
            : "El estudiante no tenía votos registrados."
    ], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }

    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "SQL Error: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>