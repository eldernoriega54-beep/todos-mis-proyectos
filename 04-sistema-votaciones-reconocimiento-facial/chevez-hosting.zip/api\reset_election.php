<?php
require_once 'config.php';
header('Content-Type: application/json');

try {
    $conn->beginTransaction();

    // 1. Borrar todos los votos
    $conn->exec("DELETE FROM votos");

    // 2. Borrar fotos de candidatos del servidor
    $stmt = $conn->query("SELECT foto_url FROM candidatos");
    $cands = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cands as $c) {
        if (!empty($c['foto_url'])) {
            $file = '../' . $c['foto_url'];
            if (file_exists($file)) unlink($file);
        }
    }

    // 3. Borrar todos los candidatos
    $conn->exec("DELETE FROM candidatos");

    // 4. Resetear estado de voto de todos los usuarios
    $conn->exec("UPDATE usuarios SET ya_voto = 0");

    // 5. Resetear auto-increments
    $conn->exec("ALTER TABLE votos AUTO_INCREMENT = 1");
    $conn->exec("ALTER TABLE candidatos AUTO_INCREMENT = 1");

    $conn->commit();

    echo json_encode([
        "status" => "success",
        "message" => "Votación reiniciada. Todos los candidatos y votos fueron eliminados."
    ]);
} catch (PDOException $e) {
    if ($conn->inTransaction()) $conn->rollBack();
    error_log("[reset_election.php] " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Error al reiniciar: " . $e->getMessage()]);
}
?>
