<?php
require __DIR__ . '/config.php';
require __DIR__ . '/vendor/autoload.php';
use Shuchkin\SimpleXLSX;

$file = 'C:/Users/ELDER NORIEGA/Downloads/VotacionesChevez2026-VERSION-FUNCIONAL/Base Datos Completa 20 Julio 26.xlsx';

if ($xlsx = SimpleXLSX::parse($file)) {
    $rows = $xlsx->rows();
    $inserted = 0;
    $stmt = $conn->prepare("INSERT IGNORE INTO usuarios (nombre, correo) VALUES (:nombre, :correo)");
    
    foreach ($rows as $index => $data) {
        if ($index === 0) continue;
        if (count($data) < 3) continue;
        
        $firstName = trim($data[0] ?? '');
        $lastName = trim($data[1] ?? '');
        $email = trim($data[2] ?? '');
        
        if (empty($firstName) || empty($email)) continue;
        if (strpos($email, '@') === false) {
            $email .= '@iehchevezhn.com';
        }
        $email = strtolower($email);
        
        $nombreCompleto = $firstName . ' ' . $lastName;
        try {
            $stmt->execute([':nombre' => $nombreCompleto, ':correo' => $email]);
            if ($stmt->rowCount() > 0) $inserted++;
        } catch(PDOException $e) { }
    }
    echo "Importados $inserted usuarios exitosamente.";
} else {
    echo SimpleXLSX::parseError();
}
?>
