<?php
require_once 'api/config.php';
$tables = [];
$query = $conn->query('SHOW TABLES');
while($row = $query->fetch(PDO::FETCH_NUM)) { $tables[] = $row[0]; }
$sql = '';
foreach($tables as $table) {
    $sql .= 'DROP TABLE IF EXISTS `'.$table."`;\n";
    $row2 = $conn->query('SHOW CREATE TABLE `'.$table.'`')->fetch(PDO::FETCH_NUM);
    $sql .= $row2[1].";\n\n";
    $query = $conn->query('SELECT * FROM `'.$table.'`');
    while($row = $query->fetch(PDO::FETCH_ASSOC)) {
        $keys = array_keys($row);
        $values = array_values($row);
        $sql .= 'INSERT INTO `'.$table.'` (`'.implode('`, `', $keys).'`) VALUES (';
        foreach($values as $idx => $val) {
            if(is_null($val)) $sql .= 'NULL';
            else $sql .= $conn->quote($val);
            if($idx < count($values)-1) $sql .= ', ';
        }
        $sql .= ");\n";
    }
    $sql .= "\n\n";
}
file_put_contents('C:\Users\ELDER NORIEGA\OneDrive\Desktop\base_datos.sql', $sql);
echo "Dump OK";
?>
