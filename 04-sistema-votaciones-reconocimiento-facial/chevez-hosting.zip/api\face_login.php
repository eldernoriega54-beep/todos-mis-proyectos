<?php
require_once 'config.php';
require_once 'aws_config.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['imagen_base64'])) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Faltan datos de la imagen"]);
    exit();
}

$imagen_base64 = $data['imagen_base64'];

if (strpos($imagen_base64, ',') !== false) {
    @list($type, $imagen_base64) = explode(',', $imagen_base64);
}

$imagenBytes = base64_decode($imagen_base64);

if (!$imagenBytes) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Imagen inválida"]);
    exit();
}

try {
    $searchResult = $rekognitionClient->searchFacesByImage([
        'CollectionId' => $collectionId,
        'FaceMatchThreshold' => 95,
        'Image' => ['Bytes' => $imagenBytes],
        'MaxFaces' => 5
    ]);

    if (empty($searchResult['FaceMatches'])) {
        echo json_encode(["status" => "fail", "message" => "Rostro NO reconocido"]);
        exit();
    }

    foreach ($searchResult['FaceMatches'] as $match) {
        $faceId = $match['Face']['FaceId'] ?? '';
        $externalImageId = $match['Face']['ExternalImageId'] ?? '';
        $confidence = isset($match['Similarity']) ? floatval($match['Similarity']) : 0;

        if (empty($faceId) || $confidence < 95) {
            continue;
        }

        $stmt = $conn->prepare("
            SELECT id, nombre, correo AS email, estado, face_id
            FROM usuarios
            WHERE face_id = :face_id
            LIMIT 1
        ");
        $stmt->execute([':face_id' => $faceId]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            continue;
        }

        if (!empty($externalImageId) && strval($usuario['id']) !== strval($externalImageId)) {
            continue;
        }

        $stmtVotos = $conn->prepare("SELECT id_eleccion FROM votos WHERE id_usuario = :uid");
        $stmtVotos->execute([':uid' => $usuario['id']]);
        $usuario['voted_elections'] = $stmtVotos->fetchAll(PDO::FETCH_COLUMN);

        $usuario['confidence'] = round($confidence, 2) . '%';
        $usuario['name'] = $usuario['nombre'];

        echo json_encode([
            "status" => "success",
            "user" => $usuario
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    echo json_encode([
        "status" => "fail",
        "message" => "Rostro no vinculado correctamente al padrón de esta votación."
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    error_log("[face_login.php] Exception: " . $e->getMessage());

    if (strpos($e->getMessage(), 'There are no faces in the image') !== false) {
        echo json_encode(["status" => "fail", "message" => "No se detecta ningún rostro claro."]);
    } elseif (strpos($e->getMessage(), 'InvalidImageException') !== false) {
        echo json_encode(["status" => "fail", "message" => "La imagen capturada no es válida."]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error al conectar con el servicio de reconocimiento."]);
    }
}
?>