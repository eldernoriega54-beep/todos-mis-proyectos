export * from './icons/index.js';
export * as icons from './icons/index.js';
export * as iconsList from './icons-list.js';
export * from './aliases.js';
export { default as defaultAttributes } from './defaultAttributes.js';

export type { Icon } from './types.js';
